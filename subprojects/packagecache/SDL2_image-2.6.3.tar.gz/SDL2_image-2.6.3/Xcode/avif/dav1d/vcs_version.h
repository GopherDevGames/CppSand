/* auto-generated, do not edit */
#define DAV1D_VERSION "1.0.0-0-g99172b1"
